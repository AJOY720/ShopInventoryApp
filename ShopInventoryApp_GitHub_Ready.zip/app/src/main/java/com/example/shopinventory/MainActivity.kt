package com.example.shopinventory

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class Product(
    var name:String, var code:String, var category:String,
    var purchase:Double, var sale:Double, var stock:Int,
    var minStock:Int, var expiry:String = ""
)

class MainActivity : Activity() {
    private val products = mutableListOf<Product>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var summary: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        buildUI()
        render()
    }

    private fun buildUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,20,24,10)
        }
        val title = TextView(this).apply {
            text = "🛒 Shop Inventory"
            textSize = 25f
            setTextColor(Color.rgb(21,101,192))
            setPadding(0,0,0,12)
        }
        root.addView(title)

        summary = TextView(this).apply { textSize=16f; setPadding(0,0,0,12) }
        root.addView(summary)

        val buttons = LinearLayout(this)
        val add = Button(this).apply { text="＋ Add Product" }
        val sale = Button(this).apply { text="Sale / Stock Out" }
        buttons.addView(add, LinearLayout.LayoutParams(0,-2,1f))
        buttons.addView(sale, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(buttons)

        search = EditText(this).apply {
            hint = "🔎 Search product / code / category"
            singleLine = true
        }
        root.addView(search)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        add.setOnClickListener { addProductDialog() }
        sale.setOnClickListener { saleDialog() }
        search.addTextChangedListener(object: android.text.TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){ render() }
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        setContentView(root)
    }

    private fun addProductDialog() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(30,5,30,5) }
        fun field(h:String) = EditText(this).apply { hint=h; singleLine=true }
        val n=field("Product Name"), code=field("Product Code / Barcode")
        val cat=field("Category: মুদি / ইলেকট্রনিক্স / মেডিসিন")
        val pur=field("Purchase Price"), sp=field("Selling Price")
        val st=field("Stock"), mn=field("Minimum Stock"), ex=field("Expiry (medicine/food)")
        listOf(n,code,cat,pur,sp,st,mn,ex).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("Add Product").setView(box)
            .setPositiveButton("Save"){_,_->
                products.add(Product(n.text.toString(),code.text.toString(),cat.text.toString(),
                    pur.text.toString().toDoubleOrNull()?:0.0,sp.text.toString().toDoubleOrNull()?:0.0,
                    st.text.toString().toIntOrNull()?:0,mn.text.toString().toIntOrNull()?:0,ex.text.toString()))
                save(); render()
            }.setNegativeButton("Cancel",null).show()
    }

    private fun saleDialog() {
        if(products.isEmpty()){ toast("আগে Product যোগ করুন"); return }
        val names = products.map{"${it.name} (Stock ${it.stock})"}.toTypedArray()
        val pick=Spinner(this).apply{ adapter=ArrayAdapter<String>(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,names) }
        val qty=EditText(this).apply{hint="Quantity"; inputType=2}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,5,30,5);addView(pick);addView(qty)}
        AlertDialog.Builder(this).setTitle("Sale / Stock Out").setView(box)
            .setPositiveButton("Confirm"){_,_->
                val p=products[pick.selectedItemPosition]
                val q=qty.text.toString().toIntOrNull()?:0
                if(q>0 && q<=p.stock){p.stock-=q;save();render()} else toast("Stock যথেষ্ট নেই")
            }.setNegativeButton("Cancel",null).show()
    }

    private fun render() {
        if(!::list.isInitialized)return
        list.removeAllViews()
        val q=search.text.toString().trim().lowercase()
        val shown=products.filter{q.isEmpty() || it.name.lowercase().contains(q) || it.code.lowercase().contains(q) || it.category.lowercase().contains(q)}
        var low=0; var value=0.0
        shown.forEachIndexed{idx,p->
            value += p.purchase*p.stock
            if(p.stock<=p.minStock)low++
            val tv=TextView(this).apply{
                text="${p.name}\n${p.category} | Code: ${p.code}\nBuy ₹${p.purchase} | Sell ₹${p.sale} | Stock: ${p.stock}${if(p.expiry.isNotBlank())" | Exp: ${p.expiry}" else ""}"
                textSize=16f; setPadding(18,18,18,18)
                setBackgroundColor(if(p.stock<=p.minStock)0xFFFFE0E0.toInt() else 0xFFF3F6FA.toInt())
                setOnLongClickListener{ products.remove(p);save();render();true }
            }
            list.addView(tv,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)})
        }
        summary.text="Products: ${products.size}  |  Low Stock: $low  |  Stock Value: ₹${"%.2f".format(value)}\nLong-press a product to delete"
    }

    private fun save(){
        val a=JSONArray()
        products.forEach{p->a.put(JSONObject().apply{
            put("name",p.name);put("code",p.code);put("category",p.category);put("purchase",p.purchase);put("sale",p.sale);put("stock",p.stock);put("min",p.minStock);put("expiry",p.expiry)
        })}
        getPreferences(Context.MODE_PRIVATE).edit().putString("products",a.toString()).apply()
    }
    private fun load(){
        val s=getPreferences(Context.MODE_PRIVATE).getString("products","[]")?:"[]"
        val a=JSONArray(s)
        for(i in 0 until a.length()){val o=a.getJSONObject(i);products.add(Product(o.optString("name"),o.optString("code"),o.optString("category"),o.optDouble("purchase"),o.optDouble("sale"),o.optInt("stock"),o.optInt("min"),o.optString("expiry")))}
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
